package familytree;

import org.junit.jupiter.api.Test;

public class SimpleTest {

    @Test
    void simpleTest() {
        System.out.println("Alles funktioniert. Viel Spaß beim Programmieren!");
    }
}
